# Pirate's Voyage

## [Heist ESP](heistESP.js)
Shows you what's under each chest during a heist

## [Max Levels](maxLevels.js)
Maxes out all islands and your boat

## [Set Doubloons](setDoubloons.js)
Sets the amount of doubloons you have

## [Start Heist](startHeist.js)
Starts a heist on someone

## [Swap Doubloons](swapDoubloons.js)
Swaps doubloons with someone

## [Take Doubloons](takeDoubloons.js)
Takes doubloons from someone