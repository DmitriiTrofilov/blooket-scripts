# Crazy Kingdom

## [Choice ESP](choiceESP.js)
Shows you what will happen if you say Yes or No

## [Choice ESP Loop](choiceESPLoop.js)
Automatically shows you what will happen if you say Yes or No

## [Disable Toucan](disableToucan.js)
Never pay taxes (tax evasion)

## [Max Stats](maxStats.js)
Sets all resources to 100

## [Set Guests](setGuests.js)
Sets the amount of guests you've seen

## [Skip Guest](skipGuest.js)
Skips the current guest