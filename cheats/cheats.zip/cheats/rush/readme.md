# Blook Rush

## [Set Blooks](setBlooks.js)
Sets the amount of blooks you or your team has

## [Set Defense](setDefense.js)
Sets the amount of defense you or your team has