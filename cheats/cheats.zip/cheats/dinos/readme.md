# Deceptive Dinos

## [Auto Choose](autoChoose.js)
Automatically choose the best fossil when excavating

## [Rock ESP](rockESP.js)
Shows what each rock will give you

## [Set Fossils](setFossils.js)
Sets the amount of fossils you have

## [Set Multiplier](setMultiplier.js)
Sets fossil multiplier

## [Stop Cheating](stopCheating.js)
Undos cheating so you can't be caught