# Global

## [Auto Answer](autoAnswer.js)
Chooses the correct answer for the current question

## [Change Blook Ingame](changeBlookIngame.js)
Changes your blook

## [Every Answer Correct](everyAnswerCorrect.js)
Makes every answer correct

## [Get Daily Rewards](getDailyRewards.js)
Gives max daily tokens and XP

## [Highlight Answers](highlightAnswers.js)
Highlights the correct answers in green and incorrect in red

## [Host Any Gamemode](hostAnyGamemode.js)
Lets you switch the current gamemode on the host settings page

## [Prevent Suspension](preventSuspension.js)
Stops the API request that suspends accounts

## [Remove Random Name](removeRandomName.js)
Lets you choose your own name in random name lobbys

## [Sell Duplicate Blooks](sellDuplicateBlooks.js)
Sells all of your duplicate Uncommon to Epic blooks

## [Spam Buy Blooks](spamBuyBlooks.js)
Opens a pack a an amount of times

## [Subtle Highlight Answers](subtleHighlightAnswers.js)
Removes the shadow from correct answers

## [Use Any Blook](useAnyBlook.js)
Lets you use any blook in a lobby and view every blook in the dashboard

### [Intervals](intervals)