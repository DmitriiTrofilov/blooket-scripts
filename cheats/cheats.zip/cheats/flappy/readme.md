# Flappy Blook

## [Set Score](setScore.js)
Sets flappy blooks score

## [Toggle Ghost](toggleGhost.js)
Lets you pass through the pipes